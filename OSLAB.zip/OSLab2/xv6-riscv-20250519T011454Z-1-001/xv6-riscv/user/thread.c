#include "user/user.h"
#include "thread.h"
#include "stddef.h"
#define PGSIZE 4096

int thread_create(void (*start_routine)(void*), void *arg) {
  void *stack = malloc(PGSIZE);
  if (!stack) return -1;

  int pid = clone(stack);
  if (pid < 0) return -1;

  if (pid == 0) {
    start_routine(arg);
    exit(0);
  }

  return 0;
}

// Spinlock implementation
void lock_init(struct lock_t *lock) {
  lock->locked = 0;
}

void lock_acquire(struct lock_t *lock) {
  while (__sync_lock_test_and_set(&lock->locked, 1) != 0);
}

void lock_release(struct lock_t *lock) {
  __sync_lock_release(&lock->locked);
}
