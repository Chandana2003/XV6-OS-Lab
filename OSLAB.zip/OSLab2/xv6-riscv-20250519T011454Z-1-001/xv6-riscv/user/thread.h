#ifndef THREAD_H
#define THREAD_H

struct lock_t {
  int locked;
};
typedef struct lock_t lock_t;  

void lock_init(lock_t *);
void lock_acquire(lock_t *);
void lock_release(lock_t *);

int thread_create(void (*start_routine)(void*), void *arg);

#endif
