#ifndef KALLOC_H
#define KALLOC_H

#include "types.h"

struct run {
  struct run *next;
};

extern struct {
  struct spinlock lock;
  struct run *freelist;
} kmem;

void kinit(void);
void *kalloc(void);
void kfree(void *pa);

#endif // KALLOC_H
