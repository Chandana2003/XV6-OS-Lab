#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

struct cpu cpus[NCPU];
struct proc proc[NPROC];
struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;
int thread_id_counter = 1;  // For thread ID assignment

extern void forkret(void);
static void freeproc(struct proc *p);
extern char trampoline[];

struct spinlock wait_lock;

void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

void
procinit(void)
{
  struct proc *p;
  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  for(p = proc; p < &proc[NPROC]; p++) {
    initlock(&p->lock, "proc");
    p->state = UNUSED;
    p->kstack = KSTACK((int) (p - proc));
  }
}

int cpuid()
{
  int id = r_tp();
  return id;
}

struct cpu*
mycpu(void)
{
  int id = cpuid();
  return &cpus[id];
}

struct proc*
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;
  acquire(&pid_lock);
  pid = nextpid++;
  release(&pid_lock);
  return pid;
}

static struct proc*
allocproc(void)
{
  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if(p->state == UNUSED)
      goto found;
    else
      release(&p->lock);
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;
  p->syscall_count = 0;
  p->tickets = 10000;
  p->ticks_scheduled = 0;
  p->stride = STRIDEK / p->tickets;
  p->pass = 0;
  p->thread_id = 0;  // 🆕 parent has thread_id = 0

  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  p->pagetable = proc_pagetable(p);
  if(p->pagetable == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}

// Thread version of allocproc()
struct proc*
allocproc_thread(struct proc *parent, int thread_id)
{
  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if(p->state == UNUSED)
      goto found;
    else
      release(&p->lock);
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;
  p->syscall_count = 0;
  p->tickets = parent->tickets;
  p->ticks_scheduled = 0;
  p->stride = STRIDEK / p->tickets;
  p->pass = parent->pass;
  p->parent = parent;
  p->thread_id = thread_id;

  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  p->pagetable = parent->pagetable;

  uint64 tf_addr = TRAPFRAME - PGSIZE * thread_id;
  if (mappages(p->pagetable, tf_addr, PGSIZE, (uint64)p->trapframe, PTE_R | PTE_W) < 0) {
    kfree((void*)p->trapframe);
    p->trapframe = 0;
    p->pagetable = 0;
    p->state = UNUSED;
    release(&p->lock);
    return 0;
  }

  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}

static void
freeproc(struct proc *p)
{
  if(p->trapframe)
    kfree((void*)p->trapframe);
  p->trapframe = 0;

  // Only free page table if this is a parent thread
  if(p->thread_id == 0 && p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);

  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->parent = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
}

// (proc_pagetable, proc_freepagetable unchanged)

// ... Rest of the code (userinit, growproc, fork, exit, wait, etc.) remains the same,
// except wait() already uses freeproc(), which now handles threads safely

// ... scheduler, yield, sleep, wakeup, kill, etc. remain the same
